Sistem informasi penjualan dan perbaikan ponsel menggunakan php native

## Preview

![Preview 1](https://raw.githubusercontent.com/snowfluke/sistem-informasi-penjualan-perbaikan-ponsel-php/main/screenshots/Screenshot_2023-09-13-23-40-13_15467.png)
